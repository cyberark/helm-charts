{{/*
Expand the name of the chart.
*/}}
{{- define "conjur-kubernetes-follower.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "conjur-kubernetes-follower.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "conjur-kubernetes-follower.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "conjur-kubernetes-follower.labels" -}}
helm.sh/chart: {{ include "conjur-kubernetes-follower.chart" . }}
{{ include "conjur-kubernetes-follower.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "conjur-kubernetes-follower.selectorLabels" -}}
app.kubernetes.io/name: {{ include "conjur-kubernetes-follower.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: conjur-follower
{{- end }}

{{/*
Resolve a component resource name using a single, shared precedence rule so that
naming stays consistent across every component (ServiceAccount, Service,
Deployment, …). Precedence, highest → lowest:
  1. Explicit component override (e.g. serviceAccount.name / service.name /
     deployment.name) - always wins.
  2. fullnameOverride-derived name (via the fullname helper).
  3. nameOverride-derived name (via the fullname helper → "<release>-<nameOverride>").
  4. Chart default name - the literal "conjur-follower". This is deliberately
     NOT the Helm-conventional "<release>-<chart>" so that installs which set no
     naming values render byte-identical names to earlier chart versions
     (non-breaking).
Usage:
  {{ include "conjur-kubernetes-follower.componentName" (dict "root" . "override" .Values.service.name) }}
*/}}
{{- define "conjur-kubernetes-follower.componentName" -}}
{{- $root := .root -}}
{{- $override := .override -}}
{{- if $override -}}
{{- $override | trunc 63 | trimSuffix "-" -}}
{{- else if or $root.Values.fullnameOverride $root.Values.nameOverride -}}
{{- include "conjur-kubernetes-follower.fullname" $root -}}
{{- else -}}
conjur-follower
{{- end -}}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "conjur-kubernetes-follower.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- include "conjur-kubernetes-follower.componentName" (dict "root" . "override" .Values.serviceAccount.name) }}
{{- else }}
{{- if empty .Values.serviceAccount.name }}
{{- fail "serviceAccount.name is required when serviceAccount.create is false" }}
{{- end }}
{{- if not .Values.serviceAccount.skipExistenceCheck }}
{{- $sa := lookup "v1" "ServiceAccount" .Release.Namespace .Values.serviceAccount.name }}
{{- if not $sa }}
{{- fail (printf "ServiceAccount %q not found in namespace %q" .Values.serviceAccount.name .Release.Namespace) }}
{{- end }}
{{- end }}
{{- .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Deployment name
*/}}
{{- define "conjur-kubernetes-follower.deploymentName" -}}
{{- include "conjur-kubernetes-follower.componentName" (dict "root" . "override" .Values.deployment.name) }}
{{- end }}

{{/*
Service name
*/}}
{{- define "conjur-kubernetes-follower.serviceName" -}}
{{- include "conjur-kubernetes-follower.componentName" (dict "root" . "override" .Values.service.name) }}
{{- end }}

{{/*
Assert that a config-source input specifies at most one source.

Each config-source input (configFileFrom, deploymentConfigFileFrom,
caCertificateFrom) documents its sources as mutually exclusive: exactly one of
value / configMapKeyRef / secretKeyRef (file is no longer supported and is
rejected by the schema). Mount precedence in the templates silently favours one
source over the others, which can hide a mis-set source and leave an orphaned
ConfigMap rendered from an ignored value:. This helper fails fast at
install/lint time when more than one source is set.

Usage:
  {{ include "conjur-kubernetes-follower.assertSingleSource" (dict "source" .Values.deployment.configFileFrom "name" "deployment.configFileFrom") }}
*/}}
{{- define "conjur-kubernetes-follower.assertSingleSource" -}}
{{- $source := .source -}}
{{- $name := .name -}}
{{- if $source -}}
{{- $set := list -}}
{{- range $key := (list "value" "configMapKeyRef" "secretKeyRef") -}}
{{- if not (empty (get $source $key)) -}}
{{- $set = append $set $key -}}
{{- end -}}
{{- end -}}
{{- if gt (len $set) 1 -}}
{{- fail (printf "%s: multiple sources were set: [%s]. Specify exactly one of [.value, .configMapKeyRef, .secretKeyRef]." $name (join ", " $set)) -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Resolve effective imagePullPolicy for a container.
Per-container value takes precedence; falls back to the global image.pullPolicy.
Usage: {{ include "conjur-kubernetes-follower.imagePullPolicy" (dict "root" . "containerPolicy" .Values.follower.configurator.imagePullPolicy) }}
*/}}
{{- define "conjur-kubernetes-follower.imagePullPolicy" -}}
{{- .containerPolicy | default .root.Values.image.pullPolicy -}}
{{- end }}

{{/*
Resolve container image.
Usage: {{ include "conjur-kubernetes-follower.image" (dict "root" . "image" .Values.follower.configurator.image "digest" .Values.follower.configurator.digest) }}
Resolution paths:
  When digest is set (non-empty):
    1. registry + repository → registry/repository/image@sha256:...
    2. registry only         → registry/image@sha256:...
    3. repository only       → repository/image@sha256:...
    4. neither               → image@sha256:...
  When digest is empty, falls back to tag-based resolution:
    1. registry + repository → registry/repository/image:tag
    2. registry only         → registry/image:tag
    3. repository only       → repository/image:tag
    4. neither               → image:tag
Tag defaults to Chart.AppVersion when not explicitly set.
*/}}
{{- define "conjur-kubernetes-follower.image" -}}
{{- $root := .root -}}
{{- $image := .image -}}
{{- $digest := .digest -}}
{{- $registry := $root.Values.image.registry -}}
{{- $repository := $root.Values.image.repository -}}
{{- if $digest }}
{{- if not (regexMatch "^sha256:[a-f0-9]{64}$" $digest) -}}
{{- fail (printf "invalid digest %q for image %q: must be sha256:<64 lowercase hex chars>" $digest $image) -}}
{{- end -}}
{{- if and $registry $repository }}
{{- printf "%s/%s/%s@%s" $registry $repository $image $digest -}}
{{- else if $registry }}
{{- printf "%s/%s@%s" $registry $image $digest -}}
{{- else if $repository }}
{{- printf "%s/%s@%s" $repository $image $digest -}}
{{- else }}
{{- printf "%s@%s" $image $digest -}}
{{- end }}
{{- else }}
{{- $tag := default $root.Chart.AppVersion $root.Values.image.tag -}}
{{- if and $registry $repository }}
{{- printf "%s/%s/%s:%s" $registry $repository $image $tag -}}
{{- else if $registry }}
{{- printf "%s/%s:%s" $registry $image $tag -}}
{{- else if $repository }}
{{- printf "%s/%s:%s" $repository $image $tag -}}
{{- else }}
{{- printf "%s:%s" $image $tag -}}
{{- end }}
{{- end }}
{{- end }}

{{/*
Default per-container security context.
Usage: {{ include "conjur-kubernetes-follower.containerSecurityContext" (dict "root" . "sc" .Values.deployment.conjur.securityContext) }}

Behaviour (precedence, highest → lowest):
  1. Per-container securityContext overrides — always win. When a key is already
     present in sc (set explicitly via deployment.<container>.securityContext),
     neither global flag below will overwrite it.
  2. readOnlyRootFilesystem (global) — injected when the container has no explicit
     override; propagates the global flag value to every container whose sc does
     not already carry the key. Applied after openshift so it can override any
     future openshift-path changes to this key.
  3. openshift (global) — processed first (lowest priority); unconditionally unsets
     runAsUser because OpenShift restricted-v2 SCC rejects pods that specify it.
     This is a deliberate platform exception to the per-container precedence rule:
     each container's runAsUser is container-type-specific with no global fallback,
     so a hasKey guard cannot be used here without silently dropping runAsUser on
     non-OpenShift deployments.
*/}}
{{- define "conjur-kubernetes-follower.containerSecurityContext" -}}
{{- $openshift := .root.Values.openshift -}}
{{- $sc := deepCopy (.sc | default dict) -}}
{{- if $openshift -}}
  {{- $_ := unset $sc "runAsUser" -}}
{{- end -}}
{{- if not (hasKey $sc "readOnlyRootFilesystem") -}}
  {{- $_ := set $sc "readOnlyRootFilesystem" .root.Values.readOnlyRootFilesystem -}}
{{- end -}}
{{- toYaml $sc }}
{{- end }}

{{/*
Default pod-level security context.
If the user provides a non-empty podSecurityContext it replaces the default block entirely.
Default: supplementalGroups: [2222]
*/}}
{{- define "conjur-kubernetes-follower.podSecurityContext" -}}
{{- if not (empty .) }}
{{- toYaml . }}
{{- else -}}
supplementalGroups:
  - 2222
{{- end -}}
{{- end }}

{{/*
Accessor functions for Conjur Leader connection details.

Conjur Leader connection details can be sourced from either direct Helm install
values (supplied via --set or --values flags) or from a "Golden" ConfigMap
(previously created by installing the Cluster Prep Helm chart). These accessor
functions favor the "Golden" ConfigMap if both are provided.
*/}}

{{/*
Determine whether the Helm chart should pull Conjur Leader connection details
from a referenced "Golden" ConfigMap. This should only occur if a ConfigMap name
and namespace have been provided. Additionally eagerly loads the ConfigMap data.

Function returns a non-empty string when the "Golden" ConfigMap is in use, and
an empty string otherwise. Use it as a direct boolean, like
`if (include "goldenConfigMap" .)`.
*/}}
{{- define "conjur-kubernetes-follower.goldenConfigMap" -}}
{{- $name := .Values.leaderConfig.goldenConfigMap -}}
{{- $namespace := .Values.leaderConfig.goldenConfigMapNamespace -}}
{{- if and (not (empty $name)) (empty $namespace) -}}
{{- fail "leaderConfig.goldenConfigMap is set but leaderConfig.goldenConfigMapNamespace is empty. Both must be provided together to use a Golden ConfigMap, or both left empty to use direct values." -}}
{{- end -}}
{{- if and (empty $name) (not (empty $namespace)) -}}
{{- fail "leaderConfig.goldenConfigMapNamespace is set but leaderConfig.goldenConfigMap is empty. Both must be provided together to use a Golden ConfigMap, or both left empty to use direct values." -}}
{{- end -}}
{{- if and (not (empty $name)) (not (empty $namespace)) -}}
{{- if not (hasKey . "_goldenData") -}}
{{- $configmap := .Values.test.mock.configMap -}}
{{- if not .Values.test.mock.enabled -}}
{{- $configmap = (lookup "v1" "ConfigMap" $namespace $name) -}}
{{- end -}}
{{- if not $configmap -}}
{{- fail (printf "Golden ConfigMap %q in namespace %q not found or unreadable." $name $namespace) -}}
{{- end -}}
{{- $_ := set . "_goldenData" (default dict $configmap.data) -}}
{{- end -}}
true
{{- end -}}
{{- end }}

{{- define "conjur-kubernetes-follower.account" -}}
{{- if (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{- required "Golden ConfigMap is missing required key: conjurAccount" (get ._goldenData "conjurAccount") -}}
{{- else -}}
{{- required "leaderConfig.account is required" .Values.leaderConfig.account -}}
{{- end -}}
{{- end }}

{{- define "conjur-kubernetes-follower.hostname" -}}
{{- if (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{- required "Golden ConfigMap is missing required key: conjurApplianceUrl" (get ._goldenData "conjurApplianceUrl" | trimPrefix "https://" | trimPrefix "http://") -}}
{{- else -}}
{{- required "leaderConfig.hostname is required" .Values.leaderConfig.hostname -}}
{{- end -}}
{{- end }}

{{/*
The authentication method that the Follower will use to authenticate with the Leader.

This is an input option for both the Cluster and Namespace Prep Helm charts
(authnK8s.authnMethod and conjurConfigMap.authnMethod, respectively), but the
setting is not persisted in the ConfigMaps created by either. The installer is
responsible for installing all three charts with the same authentication scheme
specified.
*/}}
{{- define "conjur-kubernetes-follower.authentication" -}}
{{- required "leaderConfig.authentication is required" .Values.leaderConfig.authentication -}}
{{- end }}

{{- define "conjur-kubernetes-follower.authenticatorID" -}}
{{- if (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{- required "Golden ConfigMap is missing required key: authnK8sAuthenticatorID" (get ._goldenData "authnK8sAuthenticatorID") -}}
{{- else if eq .Values.leaderConfig.authentication "authn-jwt" -}}
{{- required "authnJwt.serviceID is required when leaderConfig.authentication is \"authn-jwt\"" .Values.authnJwt.serviceID -}}
{{- else -}}
{{- required "authnK8s.serviceID is required when leaderConfig.authentication is \"authn-k8s\"" .Values.authnK8s.serviceID -}}
{{- end -}}
{{- end }}

{{- define "conjur-kubernetes-follower.authnK8sServiceAccount" -}}
{{- if (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{- required "Golden ConfigMap is missing required key: authnK8sServiceAccount" (get ._goldenData "authnK8sServiceAccount") -}}
{{- else -}}
{{- required "authnK8s.serviceAccount is required when leaderConfig.authentication is \"authn-k8s\"" .Values.authnK8s.serviceAccount -}}
{{- end -}}
{{- end }}

{{- define "conjur-kubernetes-follower.authnK8sClusterRole" -}}
{{- if (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{- required "Golden ConfigMap is missing required key: authnK8sClusterRole" (get ._goldenData "authnK8sClusterRole") -}}
{{- end -}}
{{- end }}

{{- define "conjur-kubernetes-follower.authnK8sNamespace" -}}
{{- if (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{- required "Golden ConfigMap is missing required key: authnK8sNamespace" (get ._goldenData "authnK8sNamespace") -}}
{{- else -}}
{{- required "authnK8s.namespace is required when leaderConfig.authentication is \"authn-k8s\"" .Values.authnK8s.namespace -}}
{{- end -}}
{{- end }}

{{- define "conjur-kubernetes-follower.createCertificateConfigMap" -}}
{{- $ca := .Values.leaderConfig.caCertificateFrom -}}
{{- $fromValue := (and $ca $ca.value ) -}}
{{- $fromGoldenConfigMap := (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{- if or $fromValue $fromGoldenConfigMap -}}
true
{{- end -}}
{{- end }}

{{- define "conjur-kubernetes-follower.certificate" -}}
{{- if (include "conjur-kubernetes-follower.goldenConfigMap" .) -}}
{{ required "Golden ConfigMap is missing required key: conjurSslCertificate" (get ._goldenData "conjurSslCertificate" | trim) }}
{{- else -}}
{{- $ca := .Values.leaderConfig.caCertificateFrom -}}
{{- $fromValue := (and $ca $ca.value ) -}}
{{- if $fromValue -}}
{{ $ca.value | trim }}
{{- end -}}
{{- end -}}
{{- end }}
